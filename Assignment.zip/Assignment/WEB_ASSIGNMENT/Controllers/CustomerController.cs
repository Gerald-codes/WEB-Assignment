﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WEB_ASSIGNMENT.Models;
using WEB_ASSIGNMENT.DAL;
using Microsoft.AspNetCore.Http;
using System.Net.Http;
using static WEB_ASSIGNMENT.Models.Country;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Identity;

namespace WEB_ASSIGNMENT.Controllers
{
    public class CustomerController : Controller
    {
        CustomerDAL customercontext = new CustomerDAL();
        private readonly ILogger<CustomerController> _logger;

        public CustomerController(ILogger<CustomerController> logger)
        {
            _logger = logger;
        }
        public IActionResult CustomerMain()
        {
            if ((HttpContext.Session.GetString("Role") == null || HttpContext.Session.GetString("Role") != "Customer"))
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }
        public IActionResult ChangePassword()
        {

            if ((HttpContext.Session.GetString("Role") == null || HttpContext.Session.GetString("Role") != "Customer"))
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }
        [HttpPost]
        public ActionResult ChangePassword(ChangePassword password)
        {
            

            password.Email = HttpContext.Session.GetString("Email");

            List<Customer> customerList = customercontext.GetAllCustomer();
            List<string> emailList = new List<string>();
            List<string> passwordList = new List<string>();

            foreach(var item in customerList)
            {
                emailList.Add(item.Email);
                passwordList.Add(item.Password);
            }
            
                if (password.NewPassword == password.ConfirmPassword)
                {
                    if (emailList.Contains(password.Email))
                    {
                        int pos = emailList.IndexOf(password.Email);
                        if (passwordList[pos] == password.OldPassword)
                        {
                            customercontext.ChangePassword(password);
                            TempData["Message"] = "Password changed successfully";
                            return View();
                        }
                        else
                        {
                        TempData["Message"] = "Old Password is invalid";
                        return View();
                        }
                    }
                  
                }
                else
                {
                    TempData["Message"] = "New Password and Confirm Password do not match";
                    return View();

                }
            return View();
        }


        public IActionResult BookTicket()
        {

            if ((HttpContext.Session.GetString("Role") == null || HttpContext.Session.GetString("Role") != "Customer"))
            {
                return RedirectToAction("Index", "Home");
            }
            List<CustomerBookingViewModel> custFlightList = customercontext.GetCustomerRoutes();
            return View(custFlightList);
        }
        private List<SelectListItem> GetSeatClass()
        {
            List<SelectListItem> seatclass = new List<SelectListItem>();
            seatclass.Add(new SelectListItem
            {
                Value = "Economy",
                Text = "Economy"
            });
            seatclass.Add(new SelectListItem
            {
                Value = "Business",
                Text = "Business"
            });
            return seatclass;
        }
        public async Task<ActionResult> Passenger(int? id)
        {
            if ((HttpContext.Session.GetString("Role") == null || HttpContext.Session.GetString("Role") != "Customer"))
            {
                return RedirectToAction("Index", "Home");
            }
            if (id == null)
            {
                return RedirectToAction("CustomerMain");
            }
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://restcountries.eu");
            HttpResponseMessage ResponseTask = await client.GetAsync("/rest/v1/all");
            if (ResponseTask.IsSuccessStatusCode)
            {
                string data = await ResponseTask.Content.ReadAsStringAsync();
                List<CountryModel> countryModel = JsonConvert.DeserializeObject<List<CountryModel>>(data);
                var countryList = new List<SelectListItem>();
                foreach (CountryModel country in countryModel)
                {
                    var listItem = new SelectListItem { Value = country.name, Text = country.name };
                    countryList.Add(listItem);
                }
                ViewData["CountryList"] = countryList;

            }
            ViewData["SeatClassList"] = GetSeatClass();

            string emailaddr = HttpContext.Session.GetString("Email");
            Booking custinfo = customercontext.GetBookingDetails(emailaddr);
            custinfo.ScheduleID = (int) id;

            return View(custinfo);
        }
        [HttpPost]
        public async Task<ActionResult> Passenger(Booking passenger)
        {
            if (ModelState.IsValid)
            {
                if (passenger.SeatClass == "Economy")
                {
                    passenger.Amt = customercontext.GetEcoPrice(passenger.ScheduleID);
                }
                else
                {
                    passenger.Amt = customercontext.GetBusPrice(passenger.ScheduleID);
                }
                passenger.BookingID = customercontext.CreateBooking(passenger);
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri("https://restcountries.eu");
                HttpResponseMessage ResponseTask = await client.GetAsync("/rest/v1/all");
                if (ResponseTask.IsSuccessStatusCode)
                {
                    string data = await ResponseTask.Content.ReadAsStringAsync();
                    List<CountryModel> countryModel = JsonConvert.DeserializeObject<List<CountryModel>>(data);
                    var countryList = new List<SelectListItem>();
                    foreach (CountryModel country in countryModel)
                    {
                        var listItem = new SelectListItem { Value = country.name, Text = country.name };
                        countryList.Add(listItem);
                    }
                    ViewData["CountryList"] = countryList;

                }
                TempData["Message"] = "Added Passenger";
                ViewData["SeatClassList"] = GetSeatClass();
                return View(passenger);

            }
            else
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri("https://restcountries.eu");
                HttpResponseMessage ResponseTask = await client.GetAsync("/rest/v1/all");
                if (ResponseTask.IsSuccessStatusCode)
                {
                    string data = await ResponseTask.Content.ReadAsStringAsync();
                    List<CountryModel> countryModel = JsonConvert.DeserializeObject<List<CountryModel>>(data);
                    var countryList = new List<SelectListItem>();
                    foreach (CountryModel country in countryModel)
                    {
                        var listItem = new SelectListItem { Value = country.name, Text = country.name };
                        countryList.Add(listItem);
                    }
                    ViewData["CountryList"] = countryList;

                }
                ViewData["SeatClassList"] = GetSeatClass();
                return View();
            }
            
        }




        public IActionResult ViewTicket()
        {

            if ((HttpContext.Session.GetString("Role") == null || HttpContext.Session.GetString("Role") != "Customer"))
            {
                return RedirectToAction("Index", "Home");
            }
            string emailaddr = HttpContext.Session.GetString("Email");
            List<Booking> PassengerList = customercontext.GetPassengerBooking(emailaddr);
            return View(PassengerList);
        }
        public IActionResult PrintPassenger(int? id)
        {
            if ((HttpContext.Session.GetString("Role") == null || HttpContext.Session.GetString("Role") != "Customer"))
            {
                return RedirectToAction("Index", "Home");
            }
            if (id == null)
            {
                return RedirectToAction("CustomerMain");
            }
            int BookingID = (int) id;
            List<Booking> PrintList = customercontext.PrintPassenger(BookingID);
            return View(PrintList);

        }
        public IActionResult ForgotPassword()
        {

            if ((HttpContext.Session.GetString("Role") == null || HttpContext.Session.GetString("Role") != "Customer"))
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }
    }
}