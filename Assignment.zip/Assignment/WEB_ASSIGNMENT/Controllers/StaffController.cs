﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using WEB_ASSIGNMENT.DAL;
using WEB_ASSIGNMENT.Models;

namespace WEB_ASSIGNMENT.Controllers
{
    public class StaffController : Controller
    {
        public IActionResult StaffMain()
        {
            if (HttpContext.Session.GetString("Role") == null || (HttpContext.Session.GetString("Role") != "Admin" && HttpContext.Session.GetString("Role")!="Staff"))
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }

        private StaffDAL staffContext = new StaffDAL();

        // GET: Staff
        public ActionResult Index()
        {
            // Stop accessing the action if not logged in
            // or account not in the "Staff" role
            if ((HttpContext.Session.GetString("Role") == null) ||
            (HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }


            List<Staff> staffList = staffContext.GetAllStaff();
            return View(staffList);
        }

        public IActionResult CreatePersonnelRecord()
        {
            if ((HttpContext.Session.GetString("Role") == null ||
                HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            ViewData["GenderList"] = GetGender();
            ViewData["VocationList"] = GetVocation();
            return View();
        }

        private List<SelectListItem> GetStatus()
        {
            List<SelectListItem> status = new List<SelectListItem>();
            status.Add(new SelectListItem
            {
                Value = "Active",
                Text = "Active"
            });
            status.Add(new SelectListItem
            {
                Value = "Inactive",
                Text = "Inactive"
            });
            return status;
        }

        private List<SelectListItem> GetGender()
        {
            List<SelectListItem> gender = new List<SelectListItem>();
            gender.Add(new SelectListItem
            {
                Value = "M",
                Text = "M"
            });
            gender.Add(new SelectListItem
            {
                Value = "F",
                Text = "F"
            });
            return gender;
        }

        private List<SelectListItem> GetVocation()
        {
            List<SelectListItem> Vocation = new List<SelectListItem>();
            Vocation.Add(new SelectListItem
            {
                Value = "Administrator",
                Text = "Administrator"
            });
            Vocation.Add(new SelectListItem
            {
                Value = "Pilot",
                Text = "Pilot"
            });
            Vocation.Add(new SelectListItem
            {
                Value = "Flight Attendant",
                Text = "Flight Attendant"
            });
            return Vocation;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreatePersonnelRecord(Staff staff)
        {
            StaffDAL staffcontext = new StaffDAL();

            List<Staff> staffList = staffcontext.GetAllStaff();

            List<string> EmailList = new List<string>();

            foreach (var item in staffList)
            {
                EmailList.Add(item.EmailAddr);
            }

            if (EmailList.Contains(staff.EmailAddr))
            {
                TempData["Message"] = "Email already Exists!";
                return View();
            }

            ViewData["GenderList"] = GetGender();
            ViewData["VocationList"] = GetVocation();
            
            if (ModelState.IsValid)
            {
                staff.StaffID = staffContext.Add(staff);
                TempData["Success"] = "Staff Successfully Created";
                return View();
            }
            else
            {
                return View(staff);
            }
        }
        
        public IActionResult ViewPersonnelandFlight(int? id)
        {
            if ((HttpContext.Session.GetString("Role") == null || HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            FlightCrewViewModel flightcrewvm = new FlightCrewViewModel();
            flightcrewvm.staffList = staffContext.GetAllStaff();
            if (id != null)
            {
                ViewData["selectedstaffid"] = id.Value;
                flightcrewvm.flightScheduleList = staffContext.GetSelectedFlightSchedules(id.Value);
            }
            else
            {
                ViewData["selectedstaffid"] = "";

            }
            return View(flightcrewvm);
        }

        public ActionResult AssignPersonnelSchedule(int? id) 
        {
            if ((HttpContext.Session.GetString("Role") == null) ||
                (HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            if (id == null)
            {
                return View();
            }
            
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AssignPersonnelSchedule(FlightCrewViewModel2 flighcrewviewmodel2)
        {
            if ((HttpContext.Session.GetString("Role") == null) ||
                (HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }

            int[] staffidArray = { flighcrewviewmodel2.StaffID1, flighcrewviewmodel2.StaffID2, flighcrewviewmodel2.StaffID3, flighcrewviewmodel2.StaffID4, flighcrewviewmodel2.StaffID5, flighcrewviewmodel2.StaffID6 };

            List<int> staffidList = new List<int> { flighcrewviewmodel2.StaffID1, flighcrewviewmodel2.StaffID2, flighcrewviewmodel2.StaffID3, flighcrewviewmodel2.StaffID4, flighcrewviewmodel2.StaffID5, flighcrewviewmodel2.StaffID6 };
            int max = staffidList.Max();

            int[] count = new int[max + 1];

            for (int x = 0; x < (max + 1); x++)
            {
                for (int y = 0; y < staffidArray.Length; y++)
                {
                    if (staffidArray[y] == x)
                    {
                        count[x]++;
                    }

                }
            }

            if (ModelState.IsValid)
            {
                for (int x = 0; x < (max + 1); x++)
                {
                    if (count[x] > 1)
                    {
                        TempData["Message"] = "Matching Staff IDs";
                        return View("ViewPersonnelandFlight", "Staff");
                    }
                }
            
                int scheduleid = flighcrewviewmodel2.ScheduleID;
                int staffid = flighcrewviewmodel2.StaffID1;
                string role = "Flight Captain";

                staffContext.Assign(scheduleid, staffid, role);

                staffid = flighcrewviewmodel2.StaffID2;
                role = "Second Pilot";

                staffContext.Assign(scheduleid, staffid, role);

                staffid = flighcrewviewmodel2.StaffID3;
                role = "Cabin Crew Leader";

                staffContext.Assign(scheduleid, staffid, role);

                staffid = flighcrewviewmodel2.StaffID4;
                role = "Flight Attendant";

                staffContext.Assign(scheduleid, staffid, role);

                staffid = flighcrewviewmodel2.StaffID5;
                role = "Flight Attendant";

                staffContext.Assign(scheduleid, staffid, role);

                staffid = flighcrewviewmodel2.StaffID6;
                role = "Flight Attendant";

                staffContext.Assign(scheduleid, staffid, role);

                return RedirectToAction("ViewPersonnelandFlight", "Staff");
            }

            return View();
        }

        public IActionResult AssignAircraftFlight()
        {
            return View();
        }

        public IActionResult UpdateAircraftStatus()
        {
            return View();
        }

        //public IActionResult ViewPersonnelandFlight()
        //{
        //    return View();
        //}

        public IActionResult AssignPersonneltoFlight()
        {
            return View();
        }

        public IActionResult UpdatePersonnelStatus()
        {
            return View();
        }
    }
}

//Test