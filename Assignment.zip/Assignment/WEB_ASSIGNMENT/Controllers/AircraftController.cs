﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using WEB_ASSIGNMENT.DAL;
using WEB_ASSIGNMENT.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.VisualBasic;

namespace WEB_ASSIGNMENT.Controllers
{
    public class AircraftController : Controller
    {

        private AircraftDAL aircraftContext = new AircraftDAL();

        //public IActionResult Index()
        //{
        //    if ((HttpContext.Session.GetString("Role") == null) ||
        //    (HttpContext.Session.GetString("Role") != "Admin"))
        //    {
        //        return RedirectToAction("Index", "Home");
        //    }
        //    List<Aircraft> aircraftList = aircraftContext.GetAllAircraft();
        //    return View(aircraftList);
        //}
        public IActionResult CreateAircraftRecord()
        {
            if ((HttpContext.Session.GetString("Role") == null ||
                HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            ViewData["StatusList"] = GetStatus();
           
            return View();
        }
        private List<SelectListItem> GetStatus()
        {
            List<SelectListItem> status = new List<SelectListItem>();
            status.Add(new SelectListItem
            {
                Value = "Operational",
                Text = "Operational"
            });
            status.Add(new SelectListItem
            {
                Value = "Under Maintenance",
                Text = "Under Maintenance"
            });
            return status;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateAircraftRecord(Aircraft aircraft)
        {
            ViewData["StatusList"] = GetStatus();
            if (ModelState.IsValid)
            {
                aircraft.AircraftID= aircraftContext.Add(aircraft);
                TempData["Success"] = "Aircraft Successfully Created";
                return View();
            }
            else
            {
                return View(aircraft);
            }

        }

        public IActionResult ViewRequireMaintenanceAircrafts(int? id)
        {

            if ((HttpContext.Session.GetString("Role") == null ||
             HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            MaintenanceAircraftViewModel MAircraftVM = new MaintenanceAircraftViewModel();
            MAircraftVM.aircraftList = aircraftContext.GetAllRequireMaintenanceAircrafts();
            if (id != null)
            {
                ViewData["selectedAircraftID"] = id.Value;
                MAircraftVM.flightScheduleList = aircraftContext.GetAircraftFlightSchedule(id.Value);
            }
            else
            {
                ViewData["selectedAircraftID"] = "";
            }
            return View(MAircraftVM);
        }
        public IActionResult ViewAircraftFlight(int? id)
        {
            if ((HttpContext.Session.GetString("Role") == null ||
             HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            AircraftViewModel AircraftVM = new AircraftViewModel();
            AircraftVM.aircraftList = aircraftContext.GetAllAircraft();
            if (id != null)
            {
                ViewData["selectedAircraftID"] = id.Value;
                AircraftVM.flightScheduleList = aircraftContext.GetAircraftFlightSchedule(id.Value);
            }
            else
            {
                ViewData["selectedAircraftID"] = "";
            }
            return View(AircraftVM);
        }


        public ActionResult UpdateAircraftStatus(int? id)
        {
            if ((HttpContext.Session.GetString("Role") == null) ||
            (HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            if (id == null)
            {
                return RedirectToAction("ViewAircraftFlight");
            }
            ViewData["StatusList"] = GetStatus();
            Aircraft aircraft = aircraftContext.GetAircraftDetails(id.Value);
            if (id == null)
            {
                return RedirectToAction("ViewAircraftFlight");
            }
            return View(aircraft);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateAircraftStatus(Aircraft aircraft)
        {
            ViewData["StatusList"] = GetStatus();
            if (ModelState.IsValid)
            {
                if (aircraftContext.UpdateCheck(aircraft) == true)
                {
                    TempData["Message"] = "Aircraft Status cannot be updated as there are Flight Schedule Assigned!";
                }
                else
                {
                    aircraftContext.Update(aircraft);
                    TempData["Message"] = "Aircraft Status Successfully Updated";
                }
                return RedirectToAction("UpdateAircraftStatus");
            }
            else
            {
                return View(aircraft);
            }
        }

        public ActionResult ViewFlightSchedule()
        {
            if ((HttpContext.Session.GetString("Role") == null) ||
            (HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }

            ScheduleViewModel scheduleVM = new ScheduleViewModel();
            scheduleVM.scheduleList = aircraftContext.GetAllFlightSchedule();
            return View(scheduleVM);
            
        }


        public ActionResult AssignAircraftFlight(int? id)
        {
            if ((HttpContext.Session.GetString("Role") == null) ||
            (HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            if (id == null)
            {
                return RedirectToAction("ViewFlightSchedule");
            }
            ViewData["IDList"] = aircraftContext.GetAllAircraftID();
            FlightSchedule flightSchedule = aircraftContext.GetSelectedFlightSchedule(id.Value);
            if (id == null)
            {
                return RedirectToAction("ViewFLightSchedule");
            }
            return View(flightSchedule);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AssignAircraftFlight(FlightSchedule flightSchedule)
        {
            ViewData["IDList"] = aircraftContext.GetAllAircraftID();
            aircraftContext.Assign(flightSchedule);
            TempData["Success"] = "Aircraft Successfully assigned to Flight";
            TempData["Fail"] = "Aircraft Unsuccessfully assigned to Flight";
            return RedirectToAction("AssignAircraftFlight");
            //if (ModelState.IsValid)
            //{
                
            //}
            //else
            //{
            //    return View(flightSchedule);
            //}
        }

    }
}
