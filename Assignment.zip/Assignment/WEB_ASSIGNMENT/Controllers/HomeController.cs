﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WEB_ASSIGNMENT.Models;
using WEB_ASSIGNMENT.DAL;
using System.Net.Http;
using static WEB_ASSIGNMENT.Models.Country;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace WEB_ASSIGNMENT.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

       
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult News()
        {
            return View();
        }

        public IActionResult AboutUs()
        {
            return View();
        }

        public IActionResult ContactUs()
        {
            return View();
        }

        public async Task<ActionResult> CreateCustomer()
        {
            //HttpClient client = new HttpClient();
            //client.BaseAddress = new Uri("https://restcountries.eu");
            //HttpResponseMessage ResponseTask = await client.GetAsync("/rest/v1/all");
            //if (ResponseTask.IsSuccessStatusCode)
            //{
            //    string data = await ResponseTask.Content.ReadAsStringAsync();
            //    List<CountryModel> countryModel = JsonConvert.DeserializeObject<List<CountryModel>>(data);
            //     var countryList = new List<SelectListItem>();
            //    foreach (CountryModel country in countryModel)
            //    {
            //        var listItem = new SelectListItem{ Value = country.name, Text = country.name };
            //        countryList.Add(listItem);
            //    }
            //    ViewData["CountryList"] = countryList;

            //}
            return View();
            
        }

        [HttpPost]
        public ActionResult CreateCustomer(Customer customer)
        {

            CustomerDAL customercontext = new CustomerDAL();
            bool CountryExist = Country.IsCountryExists(customer.Nationality);
          

            List<Customer> customerList = customercontext.GetAllCustomer();

            List<string> EmailList = new List<string>();
            List<string> TeleList = new List<string>();


            foreach(var item in customerList)
            {
                EmailList.Add(item.Email);
                TeleList.Add(item.Telephone);
            }

          

            if (EmailList.Contains(customer.Email)){
                TempData["Message"] = "Email already Exists!";
                return View();
            }
            
            if (customer.Nationality != null)
            {
                if (CountryExist == false)
                {
                    TempData["Message"] = "Nationality does not exist!";
                    return View(customer);
                }
                else
                {
                    customer.Telephone = "+" + CountryCallingCode.GetCountryCallingCodeForCountry(customer.Nationality) + customer.Telephone;
                    bool TelNoExist = customercontext.TelephoneExists(customer.Telephone);
                    if (TelNoExist == false)
                    {
                        customercontext.Add(customer);
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        TempData["Message"] = "Telephone Number already Exists!";
                        return View(customer);
                    }
                   
                }
                
            }
            else
            {
                customercontext.Add(customer);
                return RedirectToAction("Index");
            }
        }

            public ActionResult LogOut()
        {
            // Clear all key-values pairs stored in session state
            HttpContext.Session.Clear();
            // Call the Index action of Home controller
            return RedirectToAction("Index");
        }




        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }
}
