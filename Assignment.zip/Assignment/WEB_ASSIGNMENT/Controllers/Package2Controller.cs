﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WEB_ASSIGNMENT.DAL;
using WEB_ASSIGNMENT.Models;
using System.Net.Http;
using static WEB_ASSIGNMENT.Models.Country;
using Newtonsoft.Json;


//Lim Dao Jun S10195591K
namespace WEB_ASSIGNMENT.Controllers
{
    public class Package2Controller : Controller
    {
        private Package2DAL package2Context = new Package2DAL();
        public async Task<ActionResult> CreateRoute()
        {
            if ((HttpContext.Session.GetString("Role") == null || HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://restcountries.eu");
            HttpResponseMessage ResponseTask = await client.GetAsync("/rest/v1/all");
            if (ResponseTask.IsSuccessStatusCode)
            {
                string data = await ResponseTask.Content.ReadAsStringAsync();
                List<CountryModel> countryModel = JsonConvert.DeserializeObject<List<CountryModel>>(data);
                var countryList = new List<SelectListItem>();
                foreach (CountryModel country in countryModel)
                {
                    var listItem = new SelectListItem { Value = country.name, Text = country.name };
                    countryList.Add(listItem);
                }
                ViewData["CountryList"] = countryList;
            

            }
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> CreateRoute(FlightRoute route)
        {
            
            if (ModelState.IsValid)
            {
                //bool DepartureCountryExist = Country.IsCountryExists(route.DepartureCountry);
                //bool ArrivalCountryExist = Country.IsCountryExists(route.ArrivalCountry);
                route.RouteID = package2Context.CreateRoute(route);
                TempData["Success"] = "Route Successfully Created";
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri("https://restcountries.eu");
                HttpResponseMessage ResponseTask = await client.GetAsync("/rest/v1/all");
                if (ResponseTask.IsSuccessStatusCode)
                {
                    string data = await ResponseTask.Content.ReadAsStringAsync();
                    List<CountryModel> countryModel = JsonConvert.DeserializeObject<List<CountryModel>>(data);
                    var countryList = new List<SelectListItem>();
                    foreach (CountryModel country in countryModel)
                    {
                        var listItem = new SelectListItem { Value = country.name, Text = country.name };
                        countryList.Add(listItem);
                    }
                    ViewData["CountryList"] = countryList;


                }
                return View(route);
              


            }
            else
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri("https://restcountries.eu");
                HttpResponseMessage ResponseTask = await client.GetAsync("/rest/v1/all");
                if (ResponseTask.IsSuccessStatusCode)
                {
                    string data = await ResponseTask.Content.ReadAsStringAsync();
                    List<CountryModel> countryModel = JsonConvert.DeserializeObject<List<CountryModel>>(data);
                    var countryList = new List<SelectListItem>();
                    foreach (CountryModel country in countryModel)
                    {
                        var listItem = new SelectListItem { Value = country.name, Text = country.name };
                        countryList.Add(listItem);
                    }
                    ViewData["CountryList"] = countryList;

                }
             
                return View(route);
            }
            


        }



        public IActionResult CreateSchedule()
        {
            if ((HttpContext.Session.GetString("Role") == null || HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            ViewData["StatusList"] = GetStatus();
            return View();
        }
        private List<SelectListItem> GetStatus()
        {
            List<SelectListItem> status = new List<SelectListItem>();
            status.Add(new SelectListItem
            {
                Value = "Opened",
                Text = "Opened"
            });
            status.Add(new SelectListItem
            {
                Value = "Full",
                Text = "Full"
            });
            status.Add(new SelectListItem
            {
                Value = "Delayed",
                Text = "Delayed"
            });
            status.Add(new SelectListItem
            {
                Value = "Cancelled",
                Text = "Cancelled"
            });
            return status;
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateSchedule(FlightSchedule schedule)
        {
            ViewData["StatusList"] = GetStatus();

            if (ModelState.IsValid)
            {
                //when Departure Date Time and Flight Duration is not null
                try
                {
                    int FlightDuration = package2Context.GetFlightDuration(schedule);
                    schedule.ArrivalDateTime=package2Context.CalulateArrivalTime(schedule,FlightDuration);
                    schedule.ScheduleID = package2Context.CreateSchedule(schedule);
                    TempData["Success"] = "Schedule Successfully Created";
                    return View();
                }
                //for if Departure date time or/and flight duration is null
                catch
                {

                    schedule.ScheduleID = package2Context.CreateSchedule(schedule);
                    TempData["Success"] = "Schedule Successfully Created";
                    return View();
                }



            }
            else
            {

                return View(schedule);
            }

        }
        public IActionResult ViewRouteandSchedule(int? id)
        {
            if ((HttpContext.Session.GetString("Role") == null || HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            RouteViewModel routevm = new RouteViewModel();
            routevm.routeList = package2Context.GetRoutes();
            if (id != null)
            {
                ViewData["selectedrouteid"] = id.Value;
                routevm.scheduleList = package2Context.GetSelectedFlightSchedules(id.Value);
            }
            else
            {
                ViewData["selectedrouteid"] = "";

            }
            return View(routevm);
        }

        public IActionResult UpdateSchedule(int? id)
        {
            if ((HttpContext.Session.GetString("Role") == null || HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            ScheduleViewModel schedulevm = new ScheduleViewModel();
            schedulevm.scheduleList = package2Context.GetFlightSchedules();
            if (id != null)
            {
                ViewData["selectedscheduleid"] = id.Value;
                schedulevm.bookingList = package2Context.GetCustomerBooking(id.Value);
            }
            else
            {
                ViewData["selectedscheduleid"] = "";
            }
            ViewData["StatusList"] = GetStatus();
            return View(schedulevm);
        }


        public IActionResult UpdateStatus(int? id)
        {
            if ((HttpContext.Session.GetString("Role") == null || HttpContext.Session.GetString("Role") != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            if (id == null)
            {
                return RedirectToAction("StaffMain");
            }
            FlightSchedule status = package2Context.GetUpdateDetails(id.Value);
            ViewData["StatusList"] = GetStatus();
            return View(status);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateStatus(FlightSchedule schedule)
        {
             ViewData["StatusList"] = GetStatus();
           
            if (package2Context.CheckStatus(schedule.FlightStatus,schedule.ScheduleID ) == false)
            {
                schedule.FlightStatus = package2Context.UpdateSchedule(schedule);
                
                return RedirectToAction("UpdateSchedule");
            }
            else
            {
                TempData["Error"] = "Status already "+schedule.FlightStatus ;
                return View(schedule);
            }
           
        }
    }
}