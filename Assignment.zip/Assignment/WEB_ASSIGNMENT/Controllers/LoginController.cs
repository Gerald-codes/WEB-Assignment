﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WEB_ASSIGNMENT.DAL;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WEB_ASSIGNMENT.Controllers
{
    public class LoginController : Controller
    {
        private LoginDAL LoginContext = new LoginDAL();
        public IActionResult StaffLogin()
        {
            return View();
        }   
        [HttpPost]
        public ActionResult StaffLogin(IFormCollection formData)
        {
            string loginID=formData["txtLoginID"].ToString().ToLower();
            string password = formData["txtPassword"].ToString();
            bool ValidateLogin = LoginContext.ValidateStaffPassword(loginID, password);
            bool IsAdmin=LoginContext.GetStaffVocation(loginID, password);
            if (ValidateLogin == true)
            {
                if (IsAdmin==true)
                {
                    HttpContext.Session.SetString("Role", "Admin");
                }
                else
                {
                    HttpContext.Session.SetString("Role", "Staff");
                }
               
                return RedirectToAction("StaffMain","Staff");
            }
            else
            {
                TempData["Message"] = "Invalid Login Credentials!";
                return RedirectToAction("StaffLogin");
            }
        }
        public IActionResult CustomerLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CustomerLogin(IFormCollection formData)
        {
            string loginID = formData["txtLoginID"].ToString().ToLower();
            string password = formData["txtPassword"].ToString();
            bool ValidateLogin = LoginContext.ValidateCustomerPassword(loginID, password);
            if (ValidateLogin == true)
            {
                HttpContext.Session.SetString("Role", "Customer");
                HttpContext.Session.SetString("Email", loginID);
                return RedirectToAction("CustomerMain", "Customer");
            }
            else
            {
                TempData["Message"] = "Invalid Login Credentials!";
                return RedirectToAction("CustomerLogin");
            }
           
        }
       
    }
}
