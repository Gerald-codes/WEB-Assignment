﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_ASSIGNMENT.Models
{
    public class BookingViewModel
    {
        [Display(Name = "Schedule ID")]

        public int ScheduleID { get; set; }

        [Display(Name = "Customer ID")]

        public int CustomerID { get; set; }

        [Display(Name = "Booking ID")]

        public int BookingID { get; set; }

        [Display(Name ="Customer Name")]
        public string CustName { get; set; }

        [Display(Name = "Passport Number")]
        public string PassportNo { get; set; }

        [Display(Name ="Nationality")]
        public string Nationality { get; set; }

        [Display(Name ="Telephone Number")]
        public string TelNo { get; set; }

        [Display(Name = "Email Address")]
        public string EmailAddress { get; set; }

        [Display(Name = "Seat Class")]
        public string SeatClass { get; set; }
        [Display(Name = "Remarks")]
        public string  Remarks { get; set; }
    }
}
