﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_ASSIGNMENT.Models
{
    public class AircraftViewModel
    {
        public List<Aircraft> aircraftList { get; set; }
        public List<FlightSchedule> flightScheduleList { get; set; }
        public AircraftViewModel()
        {
            aircraftList = new List<Aircraft>();
            flightScheduleList = new List<FlightSchedule>();
        }

    }
}
