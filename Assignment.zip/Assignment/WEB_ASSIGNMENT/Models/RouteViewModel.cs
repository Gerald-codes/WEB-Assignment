﻿using Microsoft.AspNetCore.Routing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_ASSIGNMENT.Models
{
    public class RouteViewModel
    {
        public List<FlightRoute> routeList { get; set; }
        public List<FlightSchedule> scheduleList{ get; set; }
        public RouteViewModel()
        {
            routeList = new List<FlightRoute>();
            scheduleList = new List<FlightSchedule>();
        }
    }
}
