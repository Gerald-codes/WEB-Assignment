﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_ASSIGNMENT.Models
{
    public class Booking
    {
        [Display(Name = "Schedule ID")]
        public int ScheduleID { get; set; }

        [Display(Name = "Customer ID")]
        public int CustomerID { get; set; }

        [Display(Name = "Booking ID")]
        public int BookingID { get; set; }

        [Display(Name = "Passenger Name")]
        public string PassengerName { get; set; }

        [Display(Name = "Passport Number")]
        public string PassportNo { get; set; }

        [Display(Name = "Nationality")]
        public string Nationality { get; set; }

        [Display(Name = "Amount Payable")]
        public double Amt { get; set; }

        [Display(Name = "Date Time Created")]
        public DateTime DateTimeCreated { get; set; }

        [Display(Name = "Seat Class")]
        public string SeatClass { get; set; }

        [Display(Name = "Remarks")]
        public string? Remarks { get; set; }
    }
}
