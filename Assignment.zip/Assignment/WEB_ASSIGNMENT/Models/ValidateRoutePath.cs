﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace WEB_ASSIGNMENT.Models
{
    public class ValidateRoutePath : ValidationAttribute
    {
        protected override ValidationResult IsValid(
    object value, ValidationContext validationContext)
        {
            FlightRoute route = (FlightRoute)validationContext.ObjectInstance;
            string DepartureCity = route.DepartureCity;
            string DepartureCountry = route.DepartureCountry;
            string ArrivalCity = route.ArrivalCity;
            string ArrivalCountry = route.ArrivalCountry;
            if (DepartureCity==ArrivalCity && DepartureCountry==ArrivalCountry)
                return new ValidationResult
                ("Routes cannot have similar departure and arrival country and city!");

            else
                return ValidationResult.Success;



        }
    }
}
