﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_ASSIGNMENT.Models
{
    public class CustomerBookingViewModel
    {
        [Display(Name = "Departure City")]
        public string DepartureCity { get; set; }


        [Display(Name = "Departure Country")]
        public string DepartureCountry { get; set; }


        [Display(Name = "Arrival City")]
        public string ArrivalCity { get; set; }

        
        [Display(Name = "Arrival Country")]
        public string ArrivalCountry { get; set; }

        [Display(Name = "Flight Duration")]
        public int FlightDuration { get; set; }

        [Display(Name = "Economy Class Price (SGD)")]
        public double EcoClassPrice { get; set; }

        [Display(Name = "Business Class Price (SGD)")]
        public double BusClassPrice { get; set; }

        [Display(Name = "Departure DateTime of Flight")]
        public DateTime DepartureDateTime { get; set; }

        [Display(Name = "Arrival DateTime of Flight")]
        public DateTime ArrivalDateTime { get; set; }

        [Display(Name = "Schedule ID")]
        public int ScheduleID { get; set; }
    }
}
