﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_ASSIGNMENT.Models
{
    public class FlightCrewViewModel
    {
        //public List<FlightCrew> flightCrewList { get; set; }
        public List<FlightSchedule> flightScheduleList { get; set; }
        public List<Staff> staffList { get; set; }

        public FlightCrewViewModel()
        {
            //flightCrewList = new List<FlightCrew>();
            flightScheduleList = new List<FlightSchedule>();
            staffList = new List<Staff>();
        }
    }
}
