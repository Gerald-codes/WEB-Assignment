﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace WEB_ASSIGNMENT.Models
{
    public class Customer
    {
        [Display(Name = "Customer ID")]
        public int CustomerID { get; set; }

        [Display(Name = "Customer Name")]
        public string CustomerName { get; set; }

        [Display(Name = "Nationality")]
        public string? Nationality { get; set; }

        [Display(Name = "Date of Birth")]
        [DataType(DataType.Date)]
        public DateTime? DOB { get; set; }

        [Display(Name = "Telephone No")]
        public string? Telephone { get; set; }

        [Display(Name = "Email Address")]
        [EmailAddress]
        // Custom Validation Attribute for checking email address exists
        public string Email { get; set; }

        [Display(Name = "Password")]
        public string Password { get; set; }
    }
}