﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_ASSIGNMENT.Models
{
    public class ScheduleViewModel
    {
        public List<BookingViewModel> bookingList { get; set; }
        public List<FlightSchedule> scheduleList { get; set; }
        public ScheduleViewModel()
        {
            bookingList = new List<BookingViewModel>();
            scheduleList = new List<FlightSchedule>();
        }
    }
}
