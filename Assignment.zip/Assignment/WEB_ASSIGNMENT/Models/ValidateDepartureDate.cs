﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using WEB_ASSIGNMENT.DAL;

namespace WEB_ASSIGNMENT.Models
{
    public class ValidateDepartureDate:ValidationAttribute
    {

        protected override ValidationResult IsValid(
      object value, ValidationContext validationContext)
        {
            FlightSchedule schedule= (FlightSchedule)validationContext.ObjectInstance;
            DateTime DepartureDateTime = Convert.ToDateTime(schedule.DepartureDateTime);
            bool datetimenull = string.IsNullOrEmpty(Convert.ToString(schedule.DepartureDateTime));
            if (DepartureDateTime >= DateTime.Today.AddDays(1) || datetimenull==true)
            {
                return ValidationResult.Success;
            }
            else
            {
                return new ValidationResult("Date must be at least one day after today!");
            }

        }
    }
}
