﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using WEB_ASSIGNMENT.DAL;

namespace WEB_ASSIGNMENT.Models
{
    public class ValidateRouteExists: ValidationAttribute
    {
        private Package2DAL package2Context = new Package2DAL();
        protected override ValidationResult IsValid(
       object value, ValidationContext validationContext)
        {
            FlightRoute route = (FlightRoute)validationContext.ObjectInstance;
            string DepartureCity = route.DepartureCity;
            string DepartureCountry = route.DepartureCountry;
            string ArrivalCity = route.ArrivalCity;
            string ArrivalCountry = route.ArrivalCountry;
            if (package2Context.RouteExist(DepartureCity,DepartureCountry,ArrivalCity,ArrivalCountry))
                return new ValidationResult
                ("This Route Already Exists!");
      
            else
                return ValidationResult.Success;



        }
    }
}
