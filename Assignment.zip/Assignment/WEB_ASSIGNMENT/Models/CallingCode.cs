﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace WEB_ASSIGNMENT.Models
{

    
        public class CountryCallingCode
        {
            public string callingCodes { get; set; }

            public static string GetCountryCallingCodeForCountry(string countryName)
            {
                string ret = null;

                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://restcountries.eu");
                    Task<HttpResponseMessage> responseTask = client.GetAsync("/rest/v2/name/" + countryName + "?fields=callingCodes");
                    responseTask.Wait();
                    HttpResponseMessage result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        Task<string> readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();
                        string data = readTask.Result;
                        data = data.Replace("[", string.Empty).Replace("]", string.Empty);
                        data = "[" + data + "]";
                        List<CountryCallingCode> countryCallingCode = JsonConvert.DeserializeObject<List<CountryCallingCode>>(data);
                        ret = countryCallingCode[0].callingCodes;

                    }
                }

                return ret;
            }
        }
 }

