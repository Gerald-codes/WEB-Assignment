﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WEB_ASSIGNMENT.Models
{
    public class Aircraft
    {
        [Display(Name = "Aircraft ID")]
        public int AircraftID { get; set; }

        [Display(Name ="Model of Aircraft")]
        [StringLength(50, ErrorMessage = "The value cannot exceed 50 characters!")]
        public string AircraftModel { get; set; }

        [Display(Name ="Number of Economy Seats")]
        [Range(0, int.MaxValue, ErrorMessage = "Please enter a value bigger than 0")]
        public int? NumEconomySeat { get; set; }

        [Display(Name ="Number of Business Seats")]
        [Range(0, int.MaxValue, ErrorMessage = "Please enter a value bigger than 0")]
        public int? NumBusinessSeat { get; set; }

        [Display(Name ="Last Date of Maintenance")]
        [DataType(DataType.Date)]
        public DateTime? DateLastMaintenance { get; set; }

        [Display(Name ="Status of Aircraft")]
        public string Status { get; set; }

    }
}
