﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WEB_ASSIGNMENT.Models
{
    public class FlightSchedule
    {

        public int ScheduleID { get; set; }

        [Display(Name = "Flight Number")]
        [StringLength(20, ErrorMessage = "The value cannot exceed 20 characters. ")]
        public string FlightNumber { get; set; }

        [Display(Name = "Route Unique Identifier")]
        [Range(0, int.MaxValue, ErrorMessage = "Please enter a value bigger than 0")]
        [ValidateRouteIdExist]
        public int RouteID { get; set; }

        [Display(Name = "Aircraft ID")]
        [Range(0, int.MaxValue, ErrorMessage = "Please enter a value bigger than 0")]
        [ValidateAircraftIDExist]
        public int? AircraftID { get; set; }
       
        [Display(Name ="Departure DateTime of Flight")]
        [ValidateDepartureDate]
        public DateTime? DepartureDateTime { get; set; }

        [Display(Name = "Arrival DateTime of Flight")]
        public DateTime?  ArrivalDateTime { get; set; }

        [Display(Name = "Economy Class Price (SGD)")]
        [Range(1, double.MaxValue, ErrorMessage = "Please enter a value bigger than 0")]

        [DisplayFormat(DataFormatString = "{0:#,##0.00}", ApplyFormatInEditMode = true)]
        public double EcoClassPrice { get; set; }

        [Display(Name = "Business Class Price (SGD)")]
        [Range(1, double.MaxValue, ErrorMessage = "Please enter a value bigger than 0")]

        [DisplayFormat(DataFormatString = "{0:#,##0.00}", ApplyFormatInEditMode = true)]
        public double BusClassPrice { get; set; }

        [Display(Name = "Flight Status")]

        public string FlightStatus { get; set; }

    }
}

//Test
