﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_ASSIGNMENT.Models
{
    public class FlightRoute
    {

        [Display(Name = "Route ID")]
        public int RouteID { get; set; }

        [Display(Name = "Departure City")]
        [RegularExpression(@"^[a-zA-Z_ ]*$", ErrorMessage = "No numbers allowed.")]
        [StringLength(50, ErrorMessage = "The value cannot exceed 50 characters. ")]
        public string DepartureCity { get; set; }


        [Display(Name = "Departure Country")]
        [RegularExpression(@"^[a-zA-Z_ ]*$", ErrorMessage = "No numbers allowed.")]
        [StringLength(50, ErrorMessage = "The value cannot exceed 50 characters. ")]

        public string DepartureCountry { get; set; }

       
        [Display(Name = "Arrival City")]
        [RegularExpression(@"^[a-zA-Z_ ]*$", ErrorMessage = "No numbers allowed.")]
        [StringLength(50, ErrorMessage = "The value cannot exceed 50 characters. ")]
        public string ArrivalCity{ get; set; }

        [ValidateRoutePath]
        [ValidateRouteExists]
        [Display(Name = "Arrival Country")]
        [RegularExpression(@"^[a-zA-Z_ ]*$", ErrorMessage = "No numbers allowed.")]
        [StringLength(50, ErrorMessage = "The value cannot exceed 50 characters. ")]
        public string ArrivalCountry { get; set; }

        [Display(Name = "Flight Duration")]
        [Range(0.1, 24, ErrorMessage = "Please enter a value bigger than 0")]
        public double? FlightDuration { get; set; }
    }
}
