﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using WEB_ASSIGNMENT.DAL;

namespace WEB_ASSIGNMENT.Models
{
    public class ValidateAircraftIDExist: ValidationAttribute
    {
        private Package2DAL package2Context = new Package2DAL();
        protected override ValidationResult IsValid(
        object value, ValidationContext validationContext)
        {
           
            int AircraftID = Convert.ToInt32(value);
            bool idnull = string.IsNullOrEmpty(Convert.ToString(value));
            FlightSchedule flightSchedule = (FlightSchedule)validationContext.ObjectInstance;
            //try
            //{
            //    FlightSchedule flightSchedule = (FlightSchedule)validationContext.ObjectInstance;
            //}
            //catch
            //{
            //    UpdateStatus updateSchedule = (UpdateStatus)validationContext.ObjectInstance;
            //}
            



            if (package2Context.AircraftIDExist(AircraftID) || idnull==true)

                return ValidationResult.Success;

            else
                return new ValidationResult
                ("Please enter a Aircraft ID that exists!");


        }
    }
}
