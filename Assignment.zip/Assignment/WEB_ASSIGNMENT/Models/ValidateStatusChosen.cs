﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using WEB_ASSIGNMENT.DAL;


namespace WEB_ASSIGNMENT.Models
{
    public class ValidateStatusChosen : ValidationAttribute
    {
        private Package2DAL package2Context = new Package2DAL();
        protected override ValidationResult IsValid(
       object value, ValidationContext validationContext)
        {
            FlightSchedule updateStatus = (FlightSchedule)validationContext.ObjectInstance;
            string FlightStatus = updateStatus.FlightStatus;
            int ScheduleID = updateStatus.ScheduleID;
            
            
            if (package2Context.CheckStatus(FlightStatus,ScheduleID))
                return new ValidationResult
                ("The Flight Status is already "+FlightStatus+"!");

            else
                return ValidationResult.Success;



        }
    }
}
