﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace WEB_ASSIGNMENT.Models
{
    public class Staff
    {
        [Display(Name = "Staff ID")]
        public int StaffID { get; set; }

        [Display(Name = "Staff Name")]
        [StringLength(50, ErrorMessage = "The value cannot exceed 50 characters. ")]
        public string StaffName { get; set; }

        [Display(Name = "Gender")]
        public char? Gender { get; set; }

        [Display(Name = "Date Employed")]
        [DataType(DataType.Date)]
        public DateTime? DateEmployed { get; set; }

        [Display(Name = "Vocation")]
        [StringLength(50, ErrorMessage = "The value cannot exceed 50 characters. ")]
        public string Vocation { get; set; }

        [Display(Name = "Email Address")]
        [EmailAddress]
        [ValidateStaffEmailExists]
        [StringLength(50, ErrorMessage = "The value cannot exceed 50 characters. ")]
        // Custom Validation Attribute for checking email address exists
        public string EmailAddr { get; set; }

        [Display(Name = "Password")]
        [StringLength(50, ErrorMessage = "The password cannot exceed 50 characters. ")]
        public string Password { get; set; }

        [Display(Name = "Status")]
        [StringLength(50, ErrorMessage = "The status cannot exceed 50 characters. ")]
        public string Status { get; set; }
    }
}
