﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_ASSIGNMENT.Models
{
    public class ChangePassword
    {
        [Display(Name = "Email Address")]
        [EmailAddress]
        // Custom Validation Attribute for checking email address exists
        public string Email { get; set; }

        [Display(Name = "OldPassword")]
        public string OldPassword { get; set; }

        [Display(Name = "NewPassword")]
        public string NewPassword { get; set; }

        [Display(Name = "ConfirmNewPassword")]
        public string ConfirmPassword { get; set; }
    }
}
