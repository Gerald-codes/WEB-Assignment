﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_ASSIGNMENT.Models
{
    public class UpdateScheduleStatus
    {
        public int ScheduleID { get; set; }

        public int? AircraftID { get; set; }

        public int RouteID { get; set; }

        [ValidateStatusChosen]
        public string FlightStatus { get; set; }
    }
}
