﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_ASSIGNMENT.Models
{
    public class FlightCrew : Staff
    {

        [Display(Name = "Schedule ID")]
        public int SceheduleID { get; set; }

        [Display(Name = "Role")]
        [StringLength(50, ErrorMessage = "The value cannot exceed 50 characters. ")]
        public string Role { get; set; }
    }
}
