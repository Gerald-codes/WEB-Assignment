﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using WEB_ASSIGNMENT.DAL;

namespace WEB_ASSIGNMENT.Models
{
    public class ValidateScheduleIDExist:ValidationAttribute
    {
        private Package2DAL package2Context = new Package2DAL();
        protected override ValidationResult IsValid(
        object value, ValidationContext validationContext)
        {

            int ScheduleID = Convert.ToInt32(value);

            //UpdateStatus updateSchedule = (UpdateStatus)validationContext.ObjectInstance;



            if (package2Context.ScheduleIDExist(ScheduleID))

                return ValidationResult.Success;

            else
                return new ValidationResult
                ("Please enter a Schedule ID that exists!");


        }
    }
}
