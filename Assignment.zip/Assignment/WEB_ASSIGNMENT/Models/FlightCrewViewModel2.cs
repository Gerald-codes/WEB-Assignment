﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_ASSIGNMENT.Models
{
    public class FlightCrewViewModel2
    {
        [Display(Name = "Schedule ID")]
        public int ScheduleID { get; set; }

        [Display(Name = "Flight Captain")]
        public int StaffID1 { get; set; }

        [Display(Name = "Second Pilot")]
        public int StaffID2 { get; set; }

        [Display(Name = "Cabin Crew Leader")]
        public int StaffID3 { get; set; }

        [Display(Name = "Flight Attendant")]
        public int StaffID4 { get; set; }

        [Display(Name = "Flight Attendant")]
        public int StaffID5 { get; set; }

        [Display(Name = "Flight Attendant")]
        public int StaffID6 { get; set; }

        [Display(Name = "Role")]
        [StringLength(50)]
        public string Role { get; set; }
    }
}
