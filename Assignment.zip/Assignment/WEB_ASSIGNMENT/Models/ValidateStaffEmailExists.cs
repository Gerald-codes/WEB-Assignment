﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using WEB_ASSIGNMENT.DAL;

namespace WEB_ASSIGNMENT.Models
{
    public class ValidateStaffEmailExists : ValidationAttribute
    {
        private StaffDAL staffContext = new StaffDAL();
        protected override ValidationResult IsValid(
        object value, ValidationContext validationContext)
        {
            // Get the email value to validate
            string email = Convert.ToString(value);
            // Casting the validation context to the "Staff" model class
            Staff staff = (Staff)validationContext.ObjectInstance;
            // Get the Staff Id from the staff instance
            int staffID = staff.StaffID;
            if (staffContext.IsEmailExist(email, staffID))
                // validation failed
                return new ValidationResult
                ("Email address already exists!");
            else
                // validation passed
                return ValidationResult.Success;
        }
    }
}
