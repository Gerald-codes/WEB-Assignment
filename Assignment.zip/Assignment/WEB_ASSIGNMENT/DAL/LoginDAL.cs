﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Data.SqlClient;

namespace WEB_ASSIGNMENT.DAL
{
    public class LoginDAL
    {
        private IConfiguration Configuration { get; }
        private SqlConnection conn;
        //Constructor
        public LoginDAL()
        {
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "Flight_ManagementConnectionString");

            conn = new SqlConnection(strConn);
        }
        public bool ValidateStaffPassword(string loginID,string password)
        {
            bool PasswordCorrect = false;
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"Select* from Staff where EmailAddr=@loginID AND Password=@password";
            cmd.Parameters.AddWithValue("@loginID", loginID);
            cmd.Parameters.AddWithValue("@password", password);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                PasswordCorrect = true;
            }
            else
            {
                PasswordCorrect = false;
            }
            reader.Close();
            conn.Close();
            return PasswordCorrect;
        }
        public bool GetStaffVocation(string loginID, string password)
        {
            bool IsAdmin = false;
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"select Vocation from Staff where EmailAddr=@loginID AND Password=@password";
            cmd.Parameters.AddWithValue("@loginID", loginID);
            cmd.Parameters.AddWithValue("@password", password);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    if (reader.GetString(0) == "Administrator")
                    {
                         IsAdmin= true;
                    }



                }
            }
            else
            {
                IsAdmin = false;
            }
            
         
            reader.Close();
            conn.Close();
            
            return IsAdmin;
        }
        public bool ValidateCustomerPassword(string loginID, string password)
        {
            bool PasswordCorrect = false;
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"Select* from Customer where EmailAddr=@loginID AND Password=@password";
            cmd.Parameters.AddWithValue("@loginID", loginID);
            cmd.Parameters.AddWithValue("@password", password);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                PasswordCorrect = true;
            }
            else
            {
                PasswordCorrect = false;
            }
            reader.Close();
            conn.Close();
            return PasswordCorrect;
        }
    }
}
