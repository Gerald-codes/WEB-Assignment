﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using WEB_ASSIGNMENT.Models;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Data;

namespace WEB_ASSIGNMENT.DAL
{
    public class AircraftDAL
    {
        private IConfiguration Configuration { get; set; }
        private SqlConnection conn;
        public AircraftDAL()
        {
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "Flight_ManagementConnectionString");
            conn = new SqlConnection(strConn);
        }
        public int Add(Aircraft aircraft)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO Aircraft ( MakeModel,
                                NumEconomySeat, NumBusinessSeat, DateLastMaintenance, Status)
                                OUTPUT INSERTED.AircraftID
                                VALUES ( @MakeModel,
                                @NumEconomySeat, @NumBusinessSeat, @DateLastMaintenance, @Status)";
            cmd.Parameters.AddWithValue("@MakeModel", aircraft.AircraftModel);
            cmd.Parameters.AddWithValue("@NumEconomySeat", aircraft.NumEconomySeat).Value=aircraft.NumEconomySeat ?? (object)DBNull.Value ;
            cmd.Parameters.AddWithValue("@NumBusinessSeat", aircraft.NumBusinessSeat).Value=aircraft.NumBusinessSeat ?? (object)DBNull.Value ;
            cmd.Parameters.AddWithValue("@DateLastMaintenance", aircraft.DateLastMaintenance).Value=aircraft.DateLastMaintenance ?? (object)DBNull.Value ;
            cmd.Parameters.AddWithValue("@Status", aircraft.Status);

            conn.Open();
            aircraft.AircraftID = (int)cmd.ExecuteScalar();
            conn.Close();
            return aircraft.AircraftID;

        }
       
        public List<Aircraft> GetAllAircraft()
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT * FROM Aircraft";
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<Aircraft> AircraftList = new List<Aircraft>();
            while (reader.Read())
            {
                AircraftList.Add(
                    new Aircraft
                    {
                        AircraftID = reader.GetInt32(0),
                        AircraftModel = reader.GetString(1),
                        NumEconomySeat = !reader.IsDBNull(2) ? reader.GetInt32(2) : (int?)null,
                        NumBusinessSeat = !reader.IsDBNull(3) ? reader.GetInt32(3) : (int?)null,
                        DateLastMaintenance = !reader.IsDBNull(4) ? reader.GetDateTime(4) : (DateTime?)null, 
                        Status = reader.GetString(5),
                    }
              );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return AircraftList;
        }

        public List<FlightSchedule> GetAircraftFlightSchedule(int AircraftID)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT * FROM FlightSchedule WHERE AircraftID = @selectedAircraft";
            cmd.Parameters.AddWithValue("@selectedAircraft", AircraftID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<FlightSchedule> FlightScheduleList = new List<FlightSchedule>();

            while (reader.Read())
            {
                FlightScheduleList.Add(
                new FlightSchedule
                {
                    ScheduleID = reader.GetInt32(0),
                    FlightNumber = reader.GetString(1), 
                    RouteID = reader.GetInt32(2),
                    AircraftID = !reader.IsDBNull(3) ? reader.GetInt32(3) : (int?)null, 
                    DepartureDateTime = !reader.IsDBNull(4) ? reader.GetDateTime(4) : (DateTime?)null,
                    ArrivalDateTime = !reader.IsDBNull(5) ? reader.GetDateTime(5) : (DateTime?)null,
                    EcoClassPrice = (double)reader.GetDecimal(6),
                    BusClassPrice = (double)reader.GetDecimal(7),                           
                    FlightStatus = reader.GetString(8),    
                }
             );
            }

            reader.Close();
            conn.Close();
            return FlightScheduleList;
        }


        public Aircraft GetAircraftDetails(int aircraftID)
        {
            Aircraft aircraft = new Aircraft();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT * FROM AIRCRAFT 
                                WHERE AircraftID = @SelectedAircraftID";
            cmd.Parameters.AddWithValue("SelectedAircraftID", aircraftID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    aircraft.AircraftID = aircraftID;
                    aircraft.AircraftModel = reader.GetString(1);
                    aircraft.NumEconomySeat = !reader.IsDBNull(2) ? reader.GetInt32(2) : (int?)null;
                    aircraft.NumBusinessSeat = !reader.IsDBNull(3) ? reader.GetInt32(3) : (int?)null;
                    aircraft.DateLastMaintenance = !reader.IsDBNull(4) ? reader.GetDateTime(4) : (DateTime?)null;
                    aircraft.Status = reader.GetString(5);
                }
            }
            reader.Close();
            conn.Close();

            return aircraft;
        }

        public bool UpdateCheck(Aircraft aircraft)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT * FROM FlightSchedule WHERE AircraftID = @SelectedAircraftID AND DepartureDateTime>=GETDATE()";
            cmd.Parameters.AddWithValue("@SelectedAircraftID", aircraft.AircraftID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            bool AssignedFlightSchedule;
            if (reader.HasRows)
            {
                AssignedFlightSchedule = true;
            }
            else
            {
                AssignedFlightSchedule = false;
            }
            reader.Close();
            conn.Close();
            return AssignedFlightSchedule;
        }
        public int Update(Aircraft aircraft)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"UPDATE Aircraft SET Status=@status 
                                WHERE AircraftID= @SelectedAircraftID";
            cmd.Parameters.AddWithValue("@status", aircraft.Status);
            cmd.Parameters.AddWithValue("@SelectedAircraftID", aircraft.AircraftID);
            conn.Open();
            int count = cmd.ExecuteNonQuery();
            conn.Close();

            return count;
        }

        public List<FlightSchedule> GetAllFlightSchedule()
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT * FROM FlightSchedule";
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<FlightSchedule> FlightScheduleList = new List<FlightSchedule>();

            while (reader.Read())
            {
                FlightScheduleList.Add(
                new FlightSchedule
                {
                    ScheduleID = reader.GetInt32(0),
                    FlightNumber = reader.GetString(1),
                    RouteID = reader.GetInt32(2),
                    AircraftID = !reader.IsDBNull(3) ? reader.GetInt32(3) : (int?)null,
                    DepartureDateTime = !reader.IsDBNull(4) ? reader.GetDateTime(4) : (DateTime?)null,
                    ArrivalDateTime = !reader.IsDBNull(5) ? reader.GetDateTime(5) : (DateTime?)null,
                    EcoClassPrice = (double)reader.GetDecimal(6),
                    BusClassPrice = (double)reader.GetDecimal(7),
                    FlightStatus = reader.GetString(8),
                }
             );
            }

            reader.Close();
            conn.Close();
            return FlightScheduleList;
        }
        
        public List<SelectListItem> GetAllAircraftID()
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT AircraftID FROM Aircraft WHERE Status !='Under Maintenance' ";
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<SelectListItem> aircraftIDList = new List<SelectListItem>();

            while (reader.Read())
            {
                aircraftIDList.Add(
                    new SelectListItem
                    {
                        Value = Convert.ToString(!reader.IsDBNull(0) ? reader.GetInt32(0) : (int?)null),
                        Text = Convert.ToString(!reader.IsDBNull(0) ? reader.GetInt32(0) : (int?)null)
            }) ;
            }

            reader.Close();
            conn.Close();
            return aircraftIDList;
        }

        public int Assign(FlightSchedule flightSchedule)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"UPDATE FlightSchedule SET AircraftID=@SelectedAircraftID
                                WHERE ScheduleID=@SelectedScheduleID AND DepartureDateTime>=GetDate()";
            cmd.Parameters.AddWithValue("@SelectedAircraftID",flightSchedule.AircraftID);
            cmd.Parameters.AddWithValue("@SelectedScheduleID",flightSchedule.ScheduleID);
            conn.Open();
            int count = cmd.ExecuteNonQuery();
            conn.Close();

            return count;
        }

        public FlightSchedule GetSelectedFlightSchedule(int scheduleID)
        {
            FlightSchedule flight = new FlightSchedule();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT * FROM FlightSchedule WHERE ScheduleID = @SelectedScheduleID";
            cmd.Parameters.AddWithValue("@SelectedScheduleID", scheduleID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
           if (reader.HasRows)
            {
               while (reader.Read())
                {
                    flight.ScheduleID = scheduleID;
                    flight.FlightNumber = reader.GetString(1);
                    flight.RouteID = reader.GetInt32(2);
                    flight.AircraftID = !reader.IsDBNull(3) ? reader.GetInt32(3) : (int?)null;
                    flight.DepartureDateTime = !reader.IsDBNull(4) ? reader.GetDateTime(4) : (DateTime?)null;
                    flight.ArrivalDateTime = !reader.IsDBNull(5) ? reader.GetDateTime(5) : (DateTime?)null;
                    flight.EcoClassPrice = (double)reader.GetDecimal(6);
                    flight.BusClassPrice = (double)reader.GetDecimal(7);
                    flight.FlightStatus = reader.GetString(8);
                }
             
            }

           if (flight.DepartureDateTime >= DateTime.Now)
            {

            }
            reader.Close();
            conn.Close();
            return flight;
        }

        public List<Aircraft> GetAllRequireMaintenanceAircrafts()
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT * FROM Aircraft WHERE DATEDIFF(DAY, DateLastMaintenance ,GETDATE()) > 30";
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<Aircraft> AircraftList = new List<Aircraft>();
            while (reader.Read())
            {
                AircraftList.Add(
                    new Aircraft
                    {
                        AircraftID = reader.GetInt32(0),
                        AircraftModel = reader.GetString(1),
                        NumEconomySeat = !reader.IsDBNull(2) ? reader.GetInt32(2) : (int?)null,
                        NumBusinessSeat = !reader.IsDBNull(3) ? reader.GetInt32(3) : (int?)null,
                        DateLastMaintenance = !reader.IsDBNull(4) ? reader.GetDateTime(4) : (DateTime?)null,
                        Status = reader.GetString(5),
                    }
              );
            }
            reader.Close();
            conn.Close();
            return AircraftList;
        }
    }
}
