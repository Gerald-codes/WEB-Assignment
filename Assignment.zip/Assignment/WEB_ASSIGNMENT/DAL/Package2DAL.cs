﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Data.SqlClient;
using WEB_ASSIGNMENT.Models;
using Microsoft.AspNetCore.Routing;

//Lim Dao Jun S10195591K
namespace WEB_ASSIGNMENT.DAL
{
    public class Package2DAL
    {
        private IConfiguration Configuration { get; }
        private SqlConnection conn;
        //Constructor
        public Package2DAL()
        {
            //Read ConnectionString from appsettings.json file
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "Flight_ManagementConnectionString");
            //Instantiate a SqlConnection object with the
            //Connection String read
            conn = new SqlConnection(strConn);
        }
        //Calculating Flight Duration to be use for calculating arrival time
        public int GetFlightDuration(FlightSchedule schedule)
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SQL statement that selects Duration from FlightRoute
            cmd.CommandText = @"select FlightDuration from FlightRoute where RouteID=@routeid";
            cmd.Parameters.AddWithValue("@routeid", schedule.RouteID);
            //Open a database connection
            conn.Open();
            int Duration = (int)cmd.ExecuteScalar();
            conn.Close();
            return (int)Duration;
        }
        // Calculating Arrival Time based on Flight Duration
        public DateTime CalulateArrivalTime(FlightSchedule schedule,int Duration)
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Sql statement to calculate arrival time based on Flight Duration
            cmd.CommandText = @"select DATEADD(HOUR,@FlightDuration,@departure) from 
                                 FlightSchedule INNER Join FlightRoute 
                                on FlightSchedule.RouteID=FlightRoute.RouteID 
                                ";
            cmd.Parameters.AddWithValue("@departure", schedule.DepartureDateTime);
            cmd.Parameters.AddWithValue("@FlightDuration", Duration);
            conn.Open();
            schedule.ArrivalDateTime = (DateTime)cmd.ExecuteScalar();
            
            
            conn.Close();


            return (DateTime)schedule.ArrivalDateTime;
        }
        //Creating Route
        public int CreateRoute(FlightRoute route)
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();

            //Specify an INSERT SQL statement which will
            //return the auto-generated Route ID after insertion
            cmd.CommandText = @"INSERT INTO FlightRoute (DepartureCity,DepartureCountry,ArrivalCity,ArrivalCountry,FlightDuration)
                                OUTPUT INSERTED.RouteID
                                VALUES(@Dcity, @Dcountry, @Acity, @Acountry,round(@Duration,0))";


            cmd.Parameters.AddWithValue("@Dcity", route.DepartureCity);
            cmd.Parameters.AddWithValue("@Dcountry", route.DepartureCountry );
            cmd.Parameters.AddWithValue("@Acity", route.ArrivalCity);
            cmd.Parameters.AddWithValue("@Acountry", route.ArrivalCountry);
            //Insert Null value if FlightDuration Object is null
            cmd.Parameters.AddWithValue("@Duration", route.FlightDuration).Value = route.FlightDuration ?? (object)DBNull.Value; ;
           


            conn.Open();
            //ExecuteScalar is used to retrieve the auto-generated
            //RouteID after executing the INSERT SQL statement
            route.RouteID = (int)cmd.ExecuteScalar();

            conn.Close();

            return route.RouteID;

        }
        public List<BookingViewModel> GetCustomerBooking(int Scheduleid)
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SQL statement that select all Booking and Customer with selected ScheduleID
            cmd.CommandText = @"select* from Booking inner join Customer on Booking.CustomerID=Customer.CustomerID WHERE ScheduleID = @selectedschedule";
            cmd.Parameters.AddWithValue("@selectedschedule", Scheduleid);
            //Open Connection to Database
            conn.Open();
            //Execute SELCT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end, save data into a booking list
            List<BookingViewModel> bookinglist = new List<BookingViewModel>();
            while(reader.Read())
            {
                bookinglist.Add(

                    new BookingViewModel
                    {
                        BookingID = reader.GetInt32(0),
                        CustomerID = reader.GetInt32(1),
                        ScheduleID = reader.GetInt32(2),
                        CustName = reader.GetString(3),
                        PassportNo = reader.GetString(4),
                        Nationality = reader.GetString(5),
                        TelNo = reader.GetString(14),
                        EmailAddress = reader.GetString(15),
                        SeatClass = reader.GetString(6),
                        Remarks = !reader.IsDBNull(8) ? reader.GetString(8) : null,
                    }
                    );

            }
            //Close DataReader
            reader.Close();

            //Close the database connection
            conn.Close();
            return bookinglist;
        }
        public List<FlightSchedule> GetFlightSchedules()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();

            //Specify the SELECT SQL statement that
            //retrieves all FlightSchedules

            cmd.CommandText = @"SELECT * FROM FlightSchedule";

            //Open a database connection
            conn.Open();
            //Execute SELCT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();

            List<FlightSchedule> scheduleList = new List<FlightSchedule>();

            //Read the record from database
            while (reader.Read())
            {
                //Adds FlightSchedule object to list
                scheduleList.Add(

                    //Fill FlightSchedule with values from data reader
                    new FlightSchedule
                    {
                        ScheduleID = reader.GetInt32(0),
                        FlightNumber = reader.GetString(1),
                        RouteID = reader.GetInt32(2),
                        EcoClassPrice = Convert.ToDouble(reader.GetDecimal(6)),
                        BusClassPrice = Convert.ToDouble(reader.GetDecimal(7)),
                        FlightStatus = reader.GetString(8),
                        AircraftID = !reader.IsDBNull(3) ? reader.GetInt32(3) : (int?)null,
                        DepartureDateTime = !reader.IsDBNull(4) ? reader.GetDateTime(4) : (DateTime?)null,
                        ArrivalDateTime = !reader.IsDBNull(5) ? reader.GetDateTime(5) : (DateTime?)null,
                    }
                    );
            }
            //Close DataReader
            reader.Close();

            //Close the database connection
            conn.Close();
            return scheduleList;



        }
        public List<FlightSchedule> GetSelectedFlightSchedules(int RouteID)
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement that
            //retrieves all attributes of FlightSchedules with specified routeid
            cmd.CommandText = @"SELECT * FROM FlightSchedule WHERE RouteID = @selectedroute";
            
            cmd.Parameters.AddWithValue("@selectedroute", RouteID);
            //Open a database connection
            conn.Open();
            //Execute SELCT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            
            List<FlightSchedule> scheduleList = new List<FlightSchedule>();
            //Read the record from database
            while (reader.Read())
            {
                //Adds FlightSchedule object to list
                scheduleList.Add(

                    //Fill FlightSchedule with values from data reader
                    new FlightSchedule
                    {
                        ScheduleID = reader.GetInt32(0),
                        FlightNumber = reader.GetString(1),
                        RouteID = reader.GetInt32(2),
                        EcoClassPrice = Convert.ToDouble(reader.GetDecimal(6)),
                        BusClassPrice = Convert.ToDouble(reader.GetDecimal(7)),
                        FlightStatus = reader.GetString(8),
                        AircraftID = !reader.IsDBNull(3) ? reader.GetInt32(3) : (int?)null,
                        DepartureDateTime = !reader.IsDBNull(4) ? reader.GetDateTime(4) : (DateTime?)null,
                        ArrivalDateTime = !reader.IsDBNull(5) ? reader.GetDateTime(5) : (DateTime?)null,
                    }
                    );
            }

            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return scheduleList;
      
            
            
        }
        public List<FlightRoute> GetRoutes()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement that
            //retrieves all attributes of FlightRoute
            cmd.CommandText = @"select * from FlightRoute";
            //Open a database connection
            conn.Open();
            //Execute SELCT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            List<FlightRoute> routeList = new List<FlightRoute>();
            //Read the record from database
            while (reader.Read())
            {
                //Adds FlightRoute object to list
                routeList.Add(
                    //Fill FlightRoute with values from data reader
                    new FlightRoute
                    {
                        RouteID = reader.GetInt32(0),
                        


                         DepartureCity= reader.GetString(1),
                        DepartureCountry = reader.GetString(2),

                       
                        ArrivalCity = reader.GetString(3),
                        ArrivalCountry = reader.GetString(4),
                        FlightDuration= !reader.IsDBNull(5) ? reader.GetInt32(5) : (int?)null,





                    }
                        
            

            
                    );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return routeList;



        }
        public FlightSchedule GetUpdateDetails(int ScheduleID)
        {
            FlightSchedule status = new FlightSchedule();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"Select* From FlightSchedule WHERE ScheduleID=@selectedID";
            cmd.Parameters.AddWithValue("@selectedID", ScheduleID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    status.ScheduleID = reader.GetInt32(0);
                    status.RouteID = reader.GetInt32(2);
                    status.AircraftID = !reader.IsDBNull(3)?reader.GetInt32(3):(int?)null;
                    

                }
            }
            reader.Close();
            conn.Close();
            return status;
        }
        public string UpdateSchedule(FlightSchedule schedule)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"UPDATE FlightSchedule SET Status=@status 
                               WHERE ScheduleID=@scheduleid AND RouteID=@routeid ";

            cmd.Parameters.AddWithValue("@status", schedule.FlightStatus);
            cmd.Parameters.AddWithValue("@scheduleid", schedule.ScheduleID);
            cmd.Parameters.AddWithValue("@routeid", schedule.RouteID);
           
            conn.Open();
            schedule.FlightStatus = (string)cmd.ExecuteScalar();
            conn.Close();
            return schedule.FlightStatus;

        }
        //Create Flight Schedule
        public int CreateSchedule(FlightSchedule schedule)
        {
            conn.Close();
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();


            //Specify an INSERT SQL statement which will
            //return the auto-generated Schedule ID after insertion
            cmd.CommandText = @"INSERT INTO FlightSchedule (FlightNumber,RouteID,AircraftID,DepartureDateTime,
                                ArrivalDateTime,EconomyClassPrice,BusinessClassPrice,Status)
                                OUTPUT INSERTED.ScheduleID
                                VALUES(@flightno, @routeid, @aircraftid, @departure,@arrival
                               ,@ecoprice,@busprice, @status)";

            cmd.Parameters.AddWithValue("@flightno", schedule.FlightNumber);
            cmd.Parameters.AddWithValue("@routeid", schedule.RouteID);
            //Inserts Null value to Flight Schedule Table if Value is null
            cmd.Parameters.AddWithValue("@aircraftid", schedule.AircraftID).Value=schedule.AircraftID ?? (object)DBNull.Value;
            //Inserts Null value to Flight Schedule Table if Value is null
            cmd.Parameters.AddWithValue("@departure", schedule.DepartureDateTime).Value=schedule.DepartureDateTime ?? (object)DBNull.Value;
            //Inserts Null value to Flight Schedule Table if Value is null
            cmd.Parameters.AddWithValue("@arrival", schedule.ArrivalDateTime).Value = schedule.ArrivalDateTime ?? (object)DBNull.Value;
            cmd.Parameters.AddWithValue("@ecoprice", schedule.EcoClassPrice);
            cmd.Parameters.AddWithValue("@busprice", schedule.BusClassPrice);
            cmd.Parameters.AddWithValue("@status", schedule.FlightStatus);

            conn.Open();

            schedule.ScheduleID = (int)cmd.ExecuteScalar();

            conn.Close();

            
           

         
            return schedule.ScheduleID;

        }
        //Validation to Check if Route ID exists
        public bool RouteIDExist(int RouteID)
        {
            bool RouteIdFound = false;
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"Select RouteID FROM FlightRoute WHERE RouteID=@SelectedID";
            cmd.Parameters.AddWithValue("@SelectedID", RouteID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            { 
                while (reader.Read())
                {
                    if (reader.GetInt32(0) ==   RouteID)
                        
                        RouteIdFound = true;
                }
            }
            else
            { 
                RouteIdFound = false; 
            }
            reader.Close();
            conn.Close();

            return RouteIdFound;
        }
        //Validation to check if ScheduleID exists
        public bool ScheduleIDExist(int ScheduleID)
        {
            bool ScheduleIDFound = false;
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"Select ScheduleID FROM FlightSchedule WHERE ScheduleID=@SelectedID";
            cmd.Parameters.AddWithValue("@SelectedID", ScheduleID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            { //Records found
                while (reader.Read())
                {
                    if (reader.GetInt32(0) == ScheduleID)

                        ScheduleIDFound = true;
                }
            }
            else
            {
                ScheduleIDFound = false;
            }
            reader.Close();
            conn.Close();

            return ScheduleIDFound;
        }
        public bool CheckStatus(string FlightStatus, int ScheduleID)
        {
            bool CheckStatus = false;
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"Select Status from FlightSchedule where ScheduleID=@SelectedID";
            cmd.Parameters.AddWithValue("@SelectedID", ScheduleID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    if (reader.GetString(0) == FlightStatus)
                    {
                        CheckStatus = true;
                    }
                }
            }
            else
            {
                CheckStatus = false;
            }
            reader.Close();
            conn.Close();
            return CheckStatus;

        }

        public bool AircraftIDExist(int AircraftID)
        {
            bool AircraftIDFound = false;
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"Select AircraftID FROM Aircraft WHERE AircraftID=@SelectedID";
            cmd.Parameters.AddWithValue("@SelectedID", AircraftID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            { //Records found
                while (reader.Read())
                {
                    if (reader.GetInt32(0) == AircraftID)

                        AircraftIDFound = true;
                }
            }
            else
            {
                AircraftIDFound = false; 
            }
            reader.Close();
            conn.Close();

            return AircraftIDFound;
        }
        //Checking if  city / country routes entered already exists
        public bool RouteExist(string DepartureCity, string DepartureCountry, string ArrivalCity, string ArrivalCountry)
        {
            bool RouteExist = false;
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"Select * FROM FlightRoute WHERE DepartureCity=@Dcity AND DepartureCountry=@Dcountry AND ArrivalCity=@Acity AND ArrivalCountry=@Acountry";
            cmd.Parameters.AddWithValue("@Dcity", DepartureCity);
            cmd.Parameters.AddWithValue("@Dcountry", DepartureCountry);
            cmd.Parameters.AddWithValue("@Acity", ArrivalCity);
            cmd.Parameters.AddWithValue("@Acountry", ArrivalCountry);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            { //Records found
                while (reader.Read())
                {
                    if (reader.GetString(1) == DepartureCity && reader.GetString(2) == DepartureCountry && reader.GetString(3) == ArrivalCity && reader.GetString(4) == ArrivalCountry)

                        RouteExist = true;
                }
            }
            else
            {
                RouteExist = false;
            }
            reader.Close();
            conn.Close();

            return RouteExist;
        }
    }
}

   
