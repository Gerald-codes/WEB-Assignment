﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using WEB_ASSIGNMENT.Models;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace WEB_ASSIGNMENT.DAL
{
    public class StaffDAL
    {
        private IConfiguration Configuration { get; }
        private SqlConnection conn;
        //Constructor
        public StaffDAL()
        {
            //Read ConnectionString from appsettings.json file
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "Flight_ManagementConnectionString");
            //Instantiate a SqlConnection object with the
            //Connection String read.
            conn = new SqlConnection(strConn);
        }
        public List<Staff> GetAllStaff()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT * FROM Staff";
            //Open a database connection
            conn.Open();
            //Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end, save data into a staff list
            List<Staff> staffList = new List<Staff>();
            while (reader.Read())
            {
                staffList.Add(
                new Staff
                {
                    StaffID = reader.GetInt32(0), 
                    StaffName = reader.GetString(1),
                    Gender = reader.GetString(2)[0],
                    DateEmployed = !reader.IsDBNull(3) ?
                                    reader.GetDateTime(3) : (DateTime?)null,
                    Vocation = reader.GetString(4), 
                    EmailAddr = reader.GetString(5), 
                    Password = reader.GetString(6), 
                    Status = reader.GetString(7)
                }
                );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return staffList;
        }

        public List<FlightSchedule> GetFlightSchedule()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT * FROM FlightSchedule";
            //Open a database connection
            conn.Open();
            //Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end, save data into a staff list
            List<FlightSchedule> scheduleList = new List<FlightSchedule>();
            while (reader.Read())
            {
                scheduleList.Add(
                new FlightSchedule
                {
                    ScheduleID = reader.GetInt32(0),
                    FlightNumber = reader.GetString(1),
                    RouteID = reader.GetInt32(2),
                    EcoClassPrice = Convert.ToDouble(reader.GetDecimal(6)),
                    BusClassPrice = Convert.ToDouble(reader.GetDecimal(7)),
                    FlightStatus = reader.GetString(8),
                    AircraftID = !reader.IsDBNull(3) ? reader.GetInt32(3) : (int?)null,
                    DepartureDateTime = !reader.IsDBNull(4) ? reader.GetDateTime(4) : (DateTime?)null,
                    ArrivalDateTime = !reader.IsDBNull(5) ? reader.GetDateTime(5) : (DateTime?)null,
                }
                ); ;
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return scheduleList;
        }

        //public FlightCrew GetSelectedFlightCrew(int scheduleID)
        //{
        //    FlightCrew flight = new FlightCrew();
        //    SqlCommand cmd = conn.CreateCommand();
        //    cmd.CommandText = @"SELECT * FROM FlightSchedule WHERE ScheduleID = @SelectedScheduleID";
        //    cmd.Parameters.AddWithValue("@SelectedScheduleID", scheduleID);
        //    conn.Open();
        //    SqlDataReader reader = cmd.ExecuteReader();
        //    if (reader.HasRows)
        //    {
        //        while (reader.Read())
        //        {
        //            flight.ScheduleID = scheduleID;
        //            flight.FlightNumber = reader.GetString(1);
        //            flight.RouteID = reader.GetInt32(2);
        //            flight.AircraftID = !reader.IsDBNull(3) ? reader.GetInt32(3) : (int?)null;
        //            flight.DepartureDateTime = !reader.IsDBNull(4) ? reader.GetDateTime(4) : (DateTime?)null;
        //            flight.ArrivalDateTime = !reader.IsDBNull(5) ? reader.GetDateTime(5) : (DateTime?)null;
        //            flight.EcoClassPrice = (double)reader.GetDecimal(6);
        //            flight.BusClassPrice = (double)reader.GetDecimal(7);
        //            flight.FlightStatus = reader.GetString(8);
        //        }

        //    }

        //    if (flight.DepartureDateTime >= DateTime.Now)
        //    {

        //    }
        //    reader.Close();
        //    conn.Close();
        //    return flight;
        //}

        public List<FlightSchedule> GetSelectedFlightSchedules(int StaffID)
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement that
            //retrieves all attributes of FlightSchedules with specified routeid
            cmd.CommandText = @"SELECT * FROM FlightCrew inner join FlightSchedule on FlightSchedule.ScheduleID = FlightCrew.ScheduleID where FlightCrew.StaffID = @selectedschedule";

            cmd.Parameters.AddWithValue("@selectedschedule", StaffID);
            //Open a database connection
            conn.Open();
            //Execute SELCT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();

            List<FlightSchedule> scheduleList = new List<FlightSchedule>();
            //Read the record from database
            while (reader.Read())
            {
                //Adds FlightSchedule object to list
                scheduleList.Add(

                    //Fill FlightSchedule with values from data reader
                    new FlightSchedule
                    {
                        ScheduleID = reader.GetInt32(0),
                        FlightNumber = reader.GetString(4),
                        RouteID = reader.GetInt32(5),
                        EcoClassPrice = Convert.ToDouble(reader.GetDecimal(9)),
                        BusClassPrice = Convert.ToDouble(reader.GetDecimal(10)),
                        FlightStatus = reader.GetString(11),
                        AircraftID = !reader.IsDBNull(6) ? reader.GetInt32(6) : (int?)null,
                        DepartureDateTime = !reader.IsDBNull(7) ? reader.GetDateTime(7) : (DateTime?)null,
                        ArrivalDateTime = !reader.IsDBNull(8) ? reader.GetDateTime(8) : (DateTime?)null,
                    }
                    );
            }

            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return scheduleList;



        }

        public List<FlightCrew> GetSelectedFlightCrew(int StaffID)
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement that
            //retrieves all attributes of FlightSchedules with specified routeid
            cmd.CommandText = @"SELECT * FROM FlightCrew WHERE StaffID = @selectedflightcrew";

            cmd.Parameters.AddWithValue("@selectedflightcrew", StaffID);
            //Open a database connection
            conn.Open();
            //Execute SELCT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();

            List<FlightCrew> flightcrewList = new List<FlightCrew>();
            //Read the record from database
            while (reader.Read())
            {
                //Adds FlightSchedule object to list
                flightcrewList.Add(

                    //Fill FlightSchedule with values from data reader
                    new FlightCrew
                    {
                        StaffID = reader.GetInt32(0),
                        SceheduleID = reader.GetInt32(1),
                        Role = reader.GetString(3)
                    }
                    );
            }

            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return flightcrewList;



        }


        public List<FlightCrew> GetFlightCrew()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT * FROM FlightCrew";
            //Open a database connection
            conn.Open();
            //Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end, save data into a staff list
            List<FlightCrew> flightCrewList = new List<FlightCrew>();
            while (reader.Read())
            {
                flightCrewList.Add(
                new FlightCrew
                {
                    StaffID = reader.GetInt32(0),
                    SceheduleID = reader.GetInt32(1),
                    Role = reader.GetString(3)
                }
                ); 
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return flightCrewList;
        }

        public List<SelectListItem> GetAllStaffID()
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"select StaffID from Staff where Status != 'Inactive' and ";
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<SelectListItem> staffIDList = new List<SelectListItem>();

            while (reader.Read())
            {
                staffIDList.Add(
                    new SelectListItem
                    {
                        Value = Convert.ToString(!reader.IsDBNull(0) ? reader.GetInt32(0) : (int?)null),
                        Text = Convert.ToString(!reader.IsDBNull(0) ? reader.GetInt32(0) : (int?)null)
                    });
            }

            reader.Close();
            conn.Close();
            return staffIDList;
        }

        public int Assign(int scheduleID, int staffID, string role)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT FlightCrew(ScheduleID, StaffID, Role)
                                VALUES(@scheduleID, @staffID, @role)";
            //Define the parameters used in SQL statement, value for each parameter
            //is retrieved from respective class's property.
            cmd.Parameters.AddWithValue("@role", role);
            cmd.Parameters.AddWithValue("@staffID", staffID);
            cmd.Parameters.AddWithValue("@scheduleID", scheduleID);
            //Open a database connection
            conn.Open();
            //ExecuteNonQuery is used for UPDATE and DELETE
            int count = cmd.ExecuteNonQuery();
            //Close the database connection
            conn.Close();
            //return count;
            return count;
        }

        public int Add(Staff staff)
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify an INSERT SQL statement which will
            //return the auto-generated StaffID after insertion
            cmd.CommandText = @"INSERT INTO Staff (StaffName, Gender, DateEmployed, Vocation,
                                EmailAddr, Password, Status)
                                OUTPUT INSERTED.StaffID
                                VALUES(@name, @gender, @dateemployed, @vocation, @email, @password, @status)";
            //Define the parameters used in SQL statement, value for each parameter
            //is retrieved from respective class's property.
            cmd.Parameters.AddWithValue("@name", staff.StaffName);
            cmd.Parameters.AddWithValue("@gender", staff.Gender);
            if (staff.DateEmployed != null)
                cmd.Parameters.AddWithValue("@dateemployed", staff.DateEmployed);
            else
                cmd.Parameters.AddWithValue("@dateemployed", DBNull.Value);

            cmd.Parameters.AddWithValue("@vocation", staff.Vocation);
            cmd.Parameters.AddWithValue("@email", staff.EmailAddr);
            cmd.Parameters.AddWithValue("@password", "p@55Staff");
            cmd.Parameters.AddWithValue("@status", "Active");

            //A connection to database must be opened before any operations made.
            conn.Open();
            //ExecuteScalar is used to retrieve the auto-generated
            //StaffID after executing the INSERT SQL statement
            staff.StaffID = (int)cmd.ExecuteScalar();
            //A connection should be closed after operations.
            conn.Close();
            //Return id when no error occurs.
            return staff.StaffID;
        }

        public bool IsEmailExist(string email, int staffID)
        {
            bool emailFound = false;
            //Create a SqlCommand object and specify the SQL statement
            //to get a staff record with the email address to be validated
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT StaffID FROM Staff
                                WHERE EmailAddr=@selectedEmail";
            cmd.Parameters.AddWithValue("@selectedEmail", email);
            //Open a database connection and excute the SQL statement
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            { //Records found
                while (reader.Read())
                {
                    if (reader.GetInt32(0) != staffID)
                        //The email address is used by another staff
                        emailFound = true;
                }
            }
            else
            { //No record
                emailFound = false; // The email address given does not exist
            }
            reader.Close();
            conn.Close();

            return emailFound;
        }
    }

}
