﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using WEB_ASSIGNMENT.Models;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;

namespace WEB_ASSIGNMENT.DAL
{
    public class CustomerDAL
    {
        private IConfiguration Configuration { get; set; }
        private SqlConnection conn;

        public CustomerDAL()
        {
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "Flight_ManagementConnectionString");

            conn = new SqlConnection(strConn);
        }

        public List<Customer> GetAllCustomer()
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT * FROM Customer ORDER BY CustomerID";
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<Customer> customerList = new List<Customer>();
            while (reader.Read())
            {
                customerList.Add(
                new Customer
                {
                    CustomerID = reader.GetInt32(0), //0: 1st column
                    CustomerName = reader.GetString(1), //1: 2nd column
                                                        //Get the first character of a string
                    Nationality = !reader.IsDBNull(2) ? reader.GetString(2) : (string?)null, //2: 3rd column
                    DOB = !reader.IsDBNull(3) ? reader.GetDateTime(3) : (DateTime?) null, //3: 4th column
                    Telephone = !reader.IsDBNull(4) ? reader.GetString(4) : (string?) null,
                    Email = reader.GetString(5),
                    Password = reader.GetString(6),
                    
                }
                );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return customerList;
        }

        public int Add(Customer customer)
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify an INSERT SQL statement which will
            //return the auto-generated StaffID after insertion
            cmd.CommandText = @"INSERT INTO Customer (CustomerName, Nationality, BirthDate, TelNo,
                                EmailAddr, Password)
                                OUTPUT INSERTED.CustomerID
                                VALUES(@name, @country, @dob, @telno, @email,@password)";
            //Define the parameters used in SQL statement, value for each parameter
            //is retrieved from respective class's property.
            cmd.Parameters.AddWithValue("@name", customer.CustomerName);
            cmd.Parameters.AddWithValue("@country", customer.Nationality).Value = customer.Nationality ?? (object)DBNull.Value; ;
            cmd.Parameters.AddWithValue("@dob", customer.DOB).Value = customer.DOB ?? (object)DBNull.Value; ;
            cmd.Parameters.AddWithValue("@telno", customer.Telephone).Value = customer.Telephone ?? (object)DBNull.Value; ;
            cmd.Parameters.AddWithValue("@email", customer.Email);
            cmd.Parameters.AddWithValue("@password", "p@55Cust");

            //A connection to database must be opened before any operations made.
            conn.Open();
            //ExecuteScalar is used to retrieve the auto-generated
            //StaffID after executing the INSERT SQL statement
            customer.CustomerID = (int)cmd.ExecuteScalar();
            //A connection should be closed after operations.
            conn.Close();
            //Return id when no error occurs.
            return customer.CustomerID;
        }

        public bool IsEmailExist(string email, int customerID)
        {
            bool emailFound = false;
            //Create a SqlCommand object and specify the SQL statement
            //to get a staff record with the email address to be validated
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT CustomerID FROM Customer
                                WHERE EmailAddr=@selectedEmail";
            cmd.Parameters.AddWithValue("@selectedEmail", email);
            //Open a database connection and excute the SQL statement
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            { //Records found
                while (reader.Read())
                {
                    if (reader.GetInt32(0) != customerID)
                        //The email address is used by another staff
                        emailFound = true;
                }
            }
            else
            { //No record
                emailFound = false; // The email address given does not exist
            }
            reader.Close();
            conn.Close();

            return emailFound;
        }

        public string ChangePassword(ChangePassword password)
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify an UPDATE SQL statement
            cmd.CommandText = @"UPDATE Customer SET Password=@password
            WHERE EmailAddr = @selectedCustomerID";

            //Define the parameters used in SQL statement, value for each parameter
            //is retrieved from respective class's property.
            cmd.Parameters.AddWithValue("@password", password.NewPassword);
            cmd.Parameters.AddWithValue("@selectedCustomerID", password.Email);

            conn.Open();
            password.NewPassword = (string)cmd.ExecuteScalar();
            conn.Close();
            return password.NewPassword;


        }
        public Booking GetBookingDetails(string emailaddr)
        {
            Booking booking = new Booking();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"select * from Customer where EmailAddr=@selectedemail";
            cmd.Parameters.AddWithValue("@selectedemail", emailaddr);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    booking.CustomerID = reader.GetInt32(0);
                }
            }
            reader.Close();
            conn.Close();
            return booking;
        }

        public double GetEcoPrice(int ScheduleID)
        {
            double price = 0.00;
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"select * from FlightSchedule where ScheduleID=@selectedschedule";
            cmd.Parameters.AddWithValue("@selectedschedule", ScheduleID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    price = Convert.ToDouble(reader.GetDecimal(6));
                }
            }
            reader.Close();
            conn.Close();
            return price;
        }
        public double GetBusPrice(int ScheduleID)
        {
            double price = 0.00;
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"select * from FlightSchedule where ScheduleID=@selectedschedule";
            cmd.Parameters.AddWithValue("@selectedschedule", ScheduleID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    price = Convert.ToDouble(reader.GetDecimal(7));
                }
            }
            reader.Close();
            conn.Close();
            return price;
        }


        public List<CustomerBookingViewModel> GetCustomerRoutes()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement that
            //retrieves all attributes of FlightRoute
            cmd.CommandText = @"select DepartureDateTime, ArrivalDateTime, EconomyClassPrice, BusinessClassPrice, DepartureCity, DepartureCountry, ArrivalCity, ArrivalCountry, ScheduleID, FlightDuration from FlightSchedule inner join FlightRoute on FlightSchedule.RouteID=FlightRoute.RouteID where Status = 'Opened' and DepartureDateTime > GETDATE() and ArrivalDateTime is not null and DepartureDateTime is not null and FlightDuration is not null";
            //Open a database connection
            conn.Open();
            //Execute SELCT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            List<CustomerBookingViewModel> customerrouteList = new List<CustomerBookingViewModel>();
            //Read the record from database
            while (reader.Read())
            {
                //Adds FlightRoute object to list
                customerrouteList.Add(
                    //Fill FlightRoute with values from data reader
                    new CustomerBookingViewModel
                    {
                        DepartureDateTime = reader.GetDateTime(0),
                        ArrivalDateTime = reader.GetDateTime(1),
                        EcoClassPrice = Convert.ToDouble(reader.GetDecimal(2)),
                        BusClassPrice = Convert.ToDouble(reader.GetDecimal(3)),
                        DepartureCity = reader.GetString(4),
                        DepartureCountry = reader.GetString(5),
                        ArrivalCity = reader.GetString(6),
                        ArrivalCountry = reader.GetString(7),
                        ScheduleID = reader.GetInt32(8),
                        FlightDuration = reader.GetInt32(9),

                    }




                    );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return customerrouteList;



        }


        public int CreateBooking(Booking booking)
        {
            SqlCommand cmd = conn.CreateCommand();

            cmd.CommandText = @"INSERT INTO Booking (CustomerID,ScheduleID,PassengerName,PassportNumber,Nationality,SeatClass,AmtPayable,Remarks,DateTimeCreated)
                                OUTPUT INSERTED.BookingID
                                VALUES(@CustID, @SchID, @PassName, @PassNum, @Nation, @SClass, @Amt, @Remarks, GETDATE())";


            cmd.Parameters.AddWithValue("@CustID", booking.CustomerID);
            cmd.Parameters.AddWithValue("@SchID", booking.ScheduleID);
            cmd.Parameters.AddWithValue("@PassName", booking.PassengerName);
            cmd.Parameters.AddWithValue("@PassNum", booking.PassportNo);
            cmd.Parameters.AddWithValue("@Nation", booking.Nationality);
            cmd.Parameters.AddWithValue("@SClass", booking.SeatClass);
            cmd.Parameters.AddWithValue("@Amt", booking.Amt);
            cmd.Parameters.AddWithValue("@Remarks", booking.Remarks).Value = booking.Remarks ?? (object)DBNull.Value; ;


            conn.Open();

            booking.BookingID = (int)cmd.ExecuteScalar();

            conn.Close();

            return booking.BookingID;

        }

        public List<Booking> GetPassengerBooking(string emailaddr)
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement that
            //retrieves all attributes of FlightRoute
            cmd.CommandText = @"select * from Booking inner join Customer  on customer.CustomerID=booking.CustomerID where EmailAddr=@selectedemail";
            cmd.Parameters.AddWithValue("@selectedemail", emailaddr);
            //Open a database connection
            conn.Open();
            //Execute SELCT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            List<Booking> passengerList = new List<Booking>();
            while (reader.Read())
            {

                passengerList.Add(
                    new Booking
                    {
                        BookingID=reader.GetInt32(0),
                        PassengerName = reader.GetString(3),
                        PassportNo = reader.GetString(4),
                        Nationality = reader.GetString(5),
                        SeatClass = reader.GetString(6),
                        Amt = Convert.ToDouble(reader.GetDecimal(7)),
                        Remarks = !reader.IsDBNull(8) ? reader.GetString(8) : null,
                    }
                    );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return passengerList;
        }

        public List<Booking> PrintPassenger(int BookingID)
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statem
            cmd.CommandText = @"select * from Booking where BookingID=@selectedbooking";
            cmd.Parameters.AddWithValue("@selectedbooking", BookingID);
            //Open a database connection
            conn.Open();
            //Execute SELCT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            List<Booking> printList = new List<Booking>();
            while (reader.Read())
            {

                printList.Add(
                    new Booking
                    {
                        BookingID = reader.GetInt32(0),
                        PassengerName = reader.GetString(3),
                        PassportNo = reader.GetString(4),
                        Nationality = reader.GetString(5),
                        SeatClass = reader.GetString(6),
                        Amt = Convert.ToDouble(reader.GetDecimal(7)),
                        Remarks = !reader.IsDBNull(8) ? reader.GetString(8) : null,
                    }
                    );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return printList;
        }
        public bool TelephoneExists(string Telephone)
        {
            bool found = false;
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"Select TelNo from Customer where TelNo=@Telephone";
            cmd.Parameters.AddWithValue("@Telephone", Telephone);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            { //Records found
                while (reader.Read())
                {
                    if (reader.GetString(0) == Telephone)
                    {
                        found = true;
                    }
                }
            }
            else
            {
                found = false;
            }
            reader.Close();
            conn.Close();

            return found;
        }
    }
}
